# Better Call Grok — Start Here

## What the idea is
An AI-driven merchandise design and sourcing app for communities and individuals. A buyer describes custom T-shirts, hoodies or joggers, previews/revises the print design, chooses ASAP / CHEAPEST / BEST QUALITY, and sees transparent supplier recommendations. Five Grok Bots can collaborate on intake, design, discovery, RFQs and operations. A Next.js + Supabase app stores authoritative state.

## The files
- **`BETTER_CALL_GROK_AI_DRIVEN_DEVELOPMENT_MASTER_SPEC.md`** — complete 13,000+ word specification, data model, API, UI, Bot roles, agent prompts, tests and demo plan.
- **`AGENTS.md`** — compact instructions recognised by many coding agents.
- **`START_HERE.md`** — this quick start.

## How to use the pack
1. Put all three Markdown files at the **root of your project/repository**.
2. Open the directory in Cursor. Create a Supabase project and Vercel project when possible.
3. Give the coding agent this prompt:

> Read AGENTS.md and the entire BETTER_CALL_GROK_AI_DRIVEN_DEVELOPMENT_MASTER_SPEC.md. You are the lead implementation engineer. Begin implementing the smallest complete P0→P3 vertical slice now. Do not stop at planning. Implement an honest DEMO_MODE fallback where credentials are missing. Test and build after each milestone, and report actual outcomes. Never contact suppliers or place orders without my approval.

4. Create five Grok Bots using Section 13 of the master specification, and a group chat of those five Bots.
5. Have Grok Bot coordinate product/research work while Cursor ships the web app. The app must not assume an undocumented server-to-Bot API.
6. Focus on the user-visible end-to-end demo before integrating phone calls or full Alibaba sourcing.

## Suggested build order
**P0** deployed shell → **P1** intake + DB → **P2** design + versioning → **P3** suppliers + mode comparison → **P4** Bot collaboration/event history → **P5** approval/demo hardening.

## Trust boundary
`DEMO_FIXTURE` quotes are simulations. A saved recommendation is not an order. A garment mockup is not automatically a print-ready file. Notion is for notes/content, not hosting the Next.js server. External actions need explicit approval.
