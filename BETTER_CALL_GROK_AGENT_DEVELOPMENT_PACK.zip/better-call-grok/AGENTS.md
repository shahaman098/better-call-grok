# Agent Instructions — Better Call Grok

**Read `BETTER_CALL_GROK_AI_DRIVEN_DEVELOPMENT_MASTER_SPEC.md` IN FULL before any changes.** It is the authoritative implementation and product contract.

## Mission
Ship the smallest truthful, fully working vertical slice for a community merchandise procurement platform:

1. Customer enters a structured shirt/hoodie order with size distribution, print phrase, destination, deadline and priority.
2. App generates a garment preview; exact text must be rendered accurately; customer can revise and approve one immutable design version.
3. App finds or loads evidence-labelled suppliers and compares ASAP, CHEAPEST and BEST_QUALITY using **deterministic** eligibility and ranking.
4. Supabase saves projects, supplier records, quotes, asset versions, approvals and activity.
5. Customer approves a recommendation. **No actual order, money transfer, supplier email or call** occurs without separate, scoped approval.

## Operating procedure
- Inspect repo and current environment before editing. Prefer implementation to extended planning.
- Execute P0 → P1 → P2 → P3 → P4 → P5 from the master spec.
- Split only independent changes across parallel agents and assign one owner per file.
- Verify current external APIs; do not invent endpoints, credentials, access permissions or supplier replies.
- Continue with a **clearly labelled** demo fixture when external provider access is missing.
- Never mark an operation successful until its real service confirms it.
- Run typecheck, lint, unit tests and build after each milestone. Fix failures before moving on.
- Require owner checks/RLS and keep service keys out of client code.
- Keep loading, error, empty and retry states functional.
- Prefer mobile-responsive simple components over purely decorative polish.
- Human must explicitly approve any email, phone call, supplier commitment, purchase, live payment, destructive migration or other irreversible action.

## Standard report after each task
```
TASK:
FILES CHANGED:
BEHAVIOUR DELIVERED:
TESTS RUN + ACTUAL RESULTS:
REAL VS DEMO INTEGRATIONS:
BLOCKERS:
NEXT SMALL TASK:
```

## Do not stop at writing a plan
Implement a testable build and deploy if deploy access is available. If it is not, report the exact blocker and give an executable local runbook, not an invented deployment URL.
